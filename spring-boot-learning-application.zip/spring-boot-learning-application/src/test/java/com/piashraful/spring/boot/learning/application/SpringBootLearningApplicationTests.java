package com.piashraful.spring.boot.learning.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
