package com.piashraful.Spring.boot.learing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLearingApplicationTests {

	@Test
	void contextLoads() {
	}

}
