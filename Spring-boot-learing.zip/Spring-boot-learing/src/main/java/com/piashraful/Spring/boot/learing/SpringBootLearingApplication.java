package com.piashraful.Spring.boot.learing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLearingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLearingApplication.class, args);
	}

}
