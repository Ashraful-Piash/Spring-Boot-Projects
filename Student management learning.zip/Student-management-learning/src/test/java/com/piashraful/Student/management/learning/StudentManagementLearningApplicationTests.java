package com.piashraful.Student.management.learning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManagementLearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
