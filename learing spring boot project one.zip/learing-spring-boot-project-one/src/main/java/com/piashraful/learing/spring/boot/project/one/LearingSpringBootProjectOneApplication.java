package com.piashraful.learing.spring.boot.project.one;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearingSpringBootProjectOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearingSpringBootProjectOneApplication.class, args);
	}

}
