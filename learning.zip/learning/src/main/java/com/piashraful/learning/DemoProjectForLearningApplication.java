package com.piashraful.learning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProjectForLearningApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoProjectForLearningApplication.class, args);
	}

}
