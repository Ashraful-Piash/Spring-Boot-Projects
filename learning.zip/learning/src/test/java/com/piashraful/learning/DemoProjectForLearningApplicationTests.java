package com.piashraful.learning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoProjectForLearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
